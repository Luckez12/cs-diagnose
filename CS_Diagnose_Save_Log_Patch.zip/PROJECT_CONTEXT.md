# CS Diagnose — Project Context

Last updated: 2026-10-02. Latest patch: **Save Diagnostic**. This is the CS Diagnose Android project based on the user's supplied official CloudStream source, not VUEO or Nuvio. Normal watching takes place in the separate official CloudStream APK; CS Diagnose is intended only to collect the most accurate diagnostic evidence for providers, network/extractors, and playback. It must **not** fix, rewrite, probe, filter out, or change the behavior of provider/stream requests to diagnose them.

## Established interface and packaging

- Keep the original official CloudStream Settings and Logcat UI unchanged. Add only the separate **Diagnose** menu below Extensions in Settings. Diagnostic's page is already accepted; Important / Full trace, Search, Copy, Clear and Close are retained.
- Sections: Live Status, Provider Process, HTTP / Network, Plugin Logs, Links / Extractor, Player, Full timeline. Live Status replaces Overview IN THE CATEGORY MENU, not as an extra panel. It is a human-readable append-only history with correctly named concurrent homepage sections and in-flight steps.
- The App targets phone ARM64, Stable Debug, separate package ID so it installs alongside official CloudStream. Never change these or workflows without asking. ZIP patches have accurate relative repo-root paths, auto-unzip via GitHub Actions; workflow `.yml` files stay separate when they need changes.
- Source of truth is the user's CURRENT GitHub `cs-diagnose` repo. v15.1 is a delta against the locally available v15 ZIP, not a verified live snapshot of GitHub; reconcile any independent GitHub edits before applying.
- Three documentation files PROJECT_CONTEXT.md, WORKFLOW_RULES.md and AI_HANDOVER.md must be updated inside EVERY future source patch ZIP.

## Diagnostic principles

- Record real observed events and provenance, not guesses. An HTTP 403 does not prove Cloudflare. A plugin-produced source does not imply playback success. An HTML Content-Type is a reported response header, not inspection of actual data bytes. One Media3 onLoadError is not necessarily final; playback may retry.
- All logs remain searchable and long technical details belong in Full trace. Sensitive URLs/queries, tokens, cookies, authorization values, raw response bodies and arbitrary exception messages must not be stored in shared reports. Sanitize by default and instruct users to inspect the copied report before sharing (redaction best-effort).
- An extension's Log.d/i/w/e may be observable through same-PID Plugin Logs best-effort; its private HTTP client or suppressed internal steps may not be. Don't invent unobserved provider internals.

## Prior work through v14

- Provider homepage sections, metadata/title/episode context, HTTP and Cloudflare hooks where instrumented; source/extension log categories; links/extractor and player tracing.
- v14 assigns a stable `source_ref` hash of URL per received/selected link and records chosen server, quality, sanitized host and endpoint, v14 typed playback exceptions, HTTP status/Content-Type on InvalidResponseCodeException, AC3/unrecognized format indicators and safe stack frames. `LINK_RECEIVED` can be matched to `PLAYER_SELECTED` and `FAIL PLAYER` by source_ref.

## v15 implementation — passive Media3 playback-load evidence

- Added `PlaybackNetworkTrace.kt`. Each selected stream's ExoPlayer instance gets its own AnalyticsListener and frozen source_ref + PLAYER operation. From actual `onLoadStarted`, `onLoadCompleted`, `onLoadError` and `onLoadCanceled`, log source_ref, loadTaskId, data/track type, requested source, sanitized initial/final URL and host, whether a redirect was observed, Range position/requested length/explicit header-presence flags, observed duration, bytes read, and **allowlisted** response Content-Type, Content-Length, Content-Range, Accept-Ranges when exposed. Typed HTTP error code only when Media3 `InvalidResponseCodeException` exposes one. The `Content-Type` classification is a hint, not a sample of the body. Error details and sanitized failing URL are split to avoid the per-event 420-character cap.
- Successful Media3 loads **do not expose a reliable HTTP success status code** through this listener. Log `http_status=not_exposed` rather than fabricate 200 or 206. Media3 may serve cache reads; report `cache_or_network=not_determined`, not "network request definitely succeeded". A changed initial/final URI proves a redirect was observed but the number of hops is not available.
- Important includes `PLAYBACK_NET_ERROR` with an explicit **nonfinal** warning. Full trace keeps starts/completions/cancels and errors; user can match by load_id, source_ref and player op. No independent requests, preflight/probing, modified player data sources, altered headers or forced retries; app should play as before.
- Known limitation: AnalyticsListener is at the media-source layer, not a raw socket trace and may not report every chunk/redirect or successful wire HTTP code. Some subtitles/audio/media/cache events may be in the same player session; `media_data_type` and `track_type` are retained to distinguish without inventing stream attribution. The 2500-entry in-memory ring may discard oldest high-volume logs; retention and UI remain unchanged here.
- Only a narrow Kotlin/JVM stub test of the new observer, static source checks and ZIP validation were run. **No local Android APK build**, no GitHub compilation or phone verification. If GitHub fails, use the actual log to correct the code.

## v15.1 Accuracy & Stability Fix (2026-09-21)

- `PLAYER_SELECTED` now labels Referer and header names as *ExtractorLink configuration* (`link_referer_configured`, `link_header_names`), not proof of headers transmitted on the wire. `PLAYBACK_NET_START` labels explicit DataSpec keys (`dataspec_referer_key`, etc.) and explicitly says `transport_headers=not_observed`. Media3 observer cannot verify factory-default/Cronet-generated headers, so false does **not** establish missing Referer on HTTP transport.
- `PLAYBACK_NET_ERROR` retains typed HTTP code only when exposed, response metadata, and Media3's reported load duration; it no longer embeds a duplicate URI that could be cut to `https://` by the entry-size limit. `PLAYBACK_NET_TARGET` holds the sanitized failing URI. `initial_final_uri_differ` reports only a comparison of two observed URIs, **not** that no redirects occurred.
- Important groups repeated nonfinal `PLAYBACK_NET_ERROR` callbacks by **player op + load_id**. It shows numbers of observed START/ERROR callbacks and the observed HTTP status set, along with the final PLAYER failure if recorded. It does not equate callback count with actual network requests or treat each load error as final. Full Trace retains individual callbacks, targets and stack frames as before.
- No new HTTP calls, probes, retries, header changes, filtering of links or playback behavior changes. Original Settings/Logcat and Diagnose layout/sections remain unchanged.
- Static/ZIP checks are not an Android compilation or device verification. Build only via existing GitHub Actions. If source has since diverged from v15, review overlap before uploading.

## v15.2 localization (2026-09-24)
- Diagnose user-facing UI, dropdown labels, Live Status history/current status, Important explanations, Plugin Logs attribution and Search messages now resolve via Android string resources using the active CloudStream Activity locale. Default resources are English; Malay (ms) has explicit translations; all other locales fall back to English for Diagnose until translated. Language changes apply when the Diagnose page is reopened after the app changes locale.
- Event keys, `provider` values, URLs, technical Full Trace field names/stage IDs, and unmodified plugin `Log.*` messages are kept as-is for search, copy, correlation and debugging. The Settings Diagnose label now references a translated resource; other official Settings and Logcat UI are unchanged.
- v15.2 patch is a delta against v15.1. No playback/network/provider/extractor instrumentation or behavior changes and no local APK build.

## Save diagnostic patch (2026-10-02)

- Base: user-uploaded `cs-diagnose-main (1).zip`, ZIP commit comment `05c7232191b9eaf7d1f15bc57e2d2672ca087a0f`. Compared all changed files with an untouched extraction of that upload; live GitHub contents were not fetched.
- Approved UI: one fixed action row **Copy | Save | Clear | Close**. Four equal-width 48dp-high buttons, reduced horizontal padding, 14sp font with 10–14sp autosizing, single-line labels. English/Malay Save and status resources follow the selected app locale. Actual device fit, font scaling and TV focus still require runtime verification.
- Save exports the same mode/category/search-filtered report as Copy, as UTF-8 `.txt`, without truncating the report. Default name includes the stable section ID, mode and local timestamp. The Android CreateDocument picker chooses the location/name; no new storage permissions, dependencies, manifest changes or workflows.
- MainActivity registers the document launcher in onCreate, before STARTED. A ViewModel holds the report snapshot in memory while the picker is open and across Activity rotation. No report is passed through Intent extras, saved-state Bundles or clipboard. IO runs on Dispatchers.IO, using application Context; success is shown only after stream close. Duplicate saves are blocked while picking/writing. Cancellation releases the snapshot without clearing trace history.
- If the OS kills the process while the picker is open, the snapshot is lost; return shows failure and the user must reopen Diagnose and save again. A failed write can leave an incomplete document. Export cannot recover entries already discarded by the existing 2500-entry trace ring.
- New: DiagnosticExport.kt. Modified: MainActivity.kt, DiagnosticDialog.kt, DiagnosticText.kt, default/Malay cs_diagnose_strings.xml, and these three project documents. Other provider/player/trace collection, Settings, Logcat and build configuration files are untouched.
- Validation: static source/diff checks, localized XML parsing and patch ZIP integrity/path checks. No local APK build, Android compilation, device UI verification or GitHub Actions run. Runtime acceptance: save a long Full Trace, compare file against Copy with identical filters; test Important, each category/search, BM/English, cancel, unavailable picker/IO failure, double tap, rotation and large font.
